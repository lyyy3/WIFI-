/// <reference types="node" />

declare let terminus: any;
export function unwrap(field: any): any | null;
export function source(): any;
export function target(): any;
