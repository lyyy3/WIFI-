import { Container } from "./container";

declare const _default: Container;
export = _default;