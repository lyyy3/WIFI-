# 自动检测到文件夹中已有的图片及新增图片 并将其转码为base64格式 然后通过MQTT上传到阿里云物联网平台
# 需要下载mqtt库  pip install paho-matt

import os
import time
import paho.mqtt.client as mqtt
import base64
import threading

# 全局变量
TXT_DIR = "base64"
encoded_files = set()  # 记录已编码的图片文件
sent_files = set()  # 记录已发送的txt文件

# 阿里云物联网平台的参数 修改双引号内的部分 建议整段复制 不要使用 + 连接符等
# 在设备页找到
product_key = "k218qu***"
device_name = "image"
device_secret = "17377c9a20ab285a***"

#查阅官方文档或阿里云物联网平台主页
region_id = "cn-shanghai"

#设备页MQTT参数 部分参数会一直变化，但无需担心，阿里云会向前兼容，仅需保持参数一致性
client_id = f"k218quVpunh.image|***"
username = f"{device_name}&{product_key}"
password = "93e04c31e5c55ec4f6360f0d3b7fc***"
MQTT_TOPIC = f"/sys/{product_key}/{device_name}/thing/event/property/post"
broker = f"***.mqtt.iothub.aliyuncs.com"
port = 1883

# MQTT回调函数
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected successfully.")
    else:
        print(f"Connection failed with result code {rc}")
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    print(msg.topic + " " + str(msg.payload))

def on_publish(client, userdata, mid):
    print(f"Message {mid} published.")

def initialize_mqtt_client():
    global client
    client = mqtt.Client(client_id=client_id)
    client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.on_message = on_message
    client.on_publish = on_publish
    client.connect(broker, port, 60)
    client.loop_start()

# 编码图片为Base64
def encode_images_to_base64(image_folder, output_folder, max_size=9*1024):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    while True:
        for filename in os.listdir(image_folder):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')) and filename not in encoded_files:
                image_path = os.path.join(image_folder, filename)
                with open(image_path, 'rb') as image_file:
                    encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
                    parts = [encoded_string[i:i+max_size] for i in range(0, len(encoded_string), max_size)]
                    for idx, part in enumerate(parts):
                        output_file = os.path.join(output_folder, f"{filename}_{idx}.txt")
                        with open(output_file, 'w') as f:
                            f.write(part)
                        print(f"Encoded part {idx} of {filename} saved to {output_file}")
                encoded_files.add(filename)
                print(f"Encoded {filename} and recorded.")
        time.sleep(1)

# 上传文件
def upload_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        client.publish(MQTT_TOPIC, f'{{"params": {{"img": "{content}"}}}}')  #将img替换为你的产品标识符
        print(f"Uploaded {file_path}")
        time.sleep(0.5)

# 处理文件上传
def process_files():
    while True:
        files = [f for f in os.listdir(TXT_DIR) if f.endswith('.txt') and f not in sent_files]
        if files:
            file_groups = {}
            for file in files:
                name_parts = file.rsplit('_', 1)[0]
                if name_parts not in file_groups:
                    file_groups[name_parts] = []
                file_groups[name_parts].append(file)
            for prefix in sorted(file_groups.keys()):
                group_files = file_groups[prefix]
                group_files.sort(key=lambda x: int(x.rsplit('_', 1)[-1].split('.')[0]))
                for file in group_files:
                    upload_file(os.path.join(TXT_DIR, file))
                    sent_files.add(file)
                client.publish(MQTT_TOPIC, '{"params": {"img": "END"}}')  #将img替换为你的产品标识符
                print(f"Uploaded END for {prefix}")
                time.sleep(5)
        time.sleep(1)

# 主函数
def main():
    image_folder = "img" #修改为你的图片存放路径 建议将该文件夹与该脚本放在同一目录下
    encoded_folder = "base64" #修改为你的Base64编码存放路径 建议将该文件夹与该脚本放在同一目录下
    initialize_mqtt_client()
    encode_thread = threading.Thread(target=encode_images_to_base64, args=(image_folder, encoded_folder))
    process_thread = threading.Thread(target=process_files)
    encode_thread.start()
    process_thread.start()
    encode_thread.join()
    process_thread.join()

if __name__ == "__main__":
    main()
